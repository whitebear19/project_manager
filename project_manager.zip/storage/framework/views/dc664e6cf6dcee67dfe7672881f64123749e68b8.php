<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card mt-50">
                <div class="card-header text-center">
                    <p>
                        <?php echo e(__('Contact Us')); ?>

                    </p>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('store.contactus')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(Session::get("message")); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <div class="form-group row">
                            <label for="email" class="col-md-12 col-form-label"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-12">
                                <input id="name" type="text" class="form-control" name="name" value="" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-12 col-form-label"><?php echo e(__('Email')); ?></label>

                            <div class="col-md-12">
                                <input id="email" type="email" class="form-control" name="email" value="" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-12 col-form-label"><?php echo e(__('Content')); ?></label>

                            <div class="col-md-12">
                                <textarea id="" cols="" name="content" class="form-control" rows="5" required></textarea>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary btn-block">
                                    <?php echo e(__('Submit')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\9\project_manager\project\project_manager\resources\views/contactus.blade.php ENDPATH**/ ?>