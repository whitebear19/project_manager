<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.easypiechart.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <?php if(Auth::user()->role > 0): ?>
        <div class="col-md-4">

        </div>
        <div class="col-md-4">
            <label for="">Sort By:</label> &nbsp;&nbsp;
            <select name="" class="form-control" id="" style="width:100px;display:inline-block;">
                <option value="">Oldest</option>
                <option value="">Latest</option>
            </select>
        </div>
        <?php endif; ?>
    </div>
    <br>
    <div class="row">
        <?php if(count($results)>0): ?>
            <div class="col-md-12 text-right">
                <input type="checkbox" name="" id="select_all">
                <button type="button" class="btn_trans btn_col_red btn_message_all" disabled>Delete All</button>
            </div>
        <?php endif; ?>
    </div>
    <br>
    <div class="row">
        <div class="col-md-12">

            <table class="table">
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <input type="checkbox" class="chk_message_item" name="message_id[]" value="<?php echo e($item->id); ?>">
                        </td>
                        <td>
                            <a href="<?php echo e(url('/dashboard/project',$item->id)); ?>">
                                <?php echo e($item->title); ?>

                            </a>
                        </td>
                        <td width="100">
                            <form action="<?php echo e(route('deleteproject')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                <input type="hidden" name="page" value="1">
                                <button type="submit" class="btn btn-denger">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>


</div>
<script type="text/javascript">
    $(document).ready(function(){
        $(document).on('click','.btn_message_all',function(){
            var id = 0;
            $.ajax({
                url:"/ajax/delete_project_all",
                type: 'get',
                dataType: 'json',
                data: {id:id},

                success: function(result){
                   if(result)
                   {
                       location.reload();
                   }
                }
            });
        });
        $("#select_all").change(function() {
            if(this.checked) {
                $(".btn_message_all").prop('disabled', false);
                $(".chk_message_item").each(function () {
                    $(this).prop('checked',true);
                });
            }
            else
            {
                $(".btn_message_all").prop('disabled', true);
                $(".chk_message_item").each(function () {
                    $(this).prop('checked',false);
                });

            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\9\project_manager\project\project_manager\resources\views/user/archieve.blade.php ENDPATH**/ ?>