<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-6">
           <p class="dash_title">User</p>
        </div>
        <div class="col-md-6" style="text-align: right;">
            <button class="btn btn-success" id="btn_addUser" data-toggle="modal" data-target="#addUserModal">Add User</button>
         </div>
        <div class="col-md-12">

            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td><b>Name</b></td>
                                    <td><b>Email</b></td>
                                    <td><b>Plan</b></td>
                                    <td><b>Paid</b></td>
                                    <td><b>Expired</b></td>
                                    <td><b>Action</b></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($item['name']); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item['email']); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item['plan']); ?>

                                        </td>
                                        <td>
                                            <?php if($item['paid'] == '1'): ?>
                                                Paid
                                            <?php else: ?>
                                                Unpaid
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                            <?php echo e(date('d-m-Y', strtotime($item['expired']))); ?>

                                        </td>
                                        <td>
                                            <button type="button" rel="tooltip" data-id="<?php echo e($item['id']); ?>" data-name="<?php echo e($item['name']); ?>" data-email="<?php echo e($item['email']); ?>" data-period="<?php echo e($item['period']); ?>" data-toggle="modal" data-target="#editUserModal" class="btn btn-success btn-mini btn-editUser">
                                                <i class="material-icons">edit</i>
                                            </button>
                                            <form action="<?php echo e(route('deleteuser')); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                                <button type="submit" rel="tooltip" class="btn btn-danger btn-mini">
                                                    <i class="material-icons">close</i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="" id="addUser-form" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="form-group">
                    <label for="">Name</label>
                    <input type="text" name="name" id="user_name" class="form-control">
                </div>
                <br>
                <div class="form-group">
                    <label for="">Email</label>
                    <input type="text" name="email" id="user_email" class="form-control">
                </div>
                <br>
                <div class="form-group">
                    <label for="">Password</label>
                    <input type="password" name="password" id="user_password" class="form-control">
                </div>
                <br>
                <div class="form-group">
                    <label for="">Plan</label>
                    <select class="form-control selectpicker" name="plan" data-style="btn btn-link" id="user_plan">
                        <option value="">----Select Plan----</option>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->period); ?>"><?php echo e($item->name); ?> &nbsp; ( $<?php echo e($item->price); ?> )</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btn-addUser" class="btn btn-primary">Add</button>
            </div>
        </form>
      </div>
    </div>
  </div>


<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="" id="editUser-form" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="user_idEdit" value="">
            <div class="modal-body">
                <div class="form-group">
                    <label for="">Name</label>
                    <input type="text" name="name" id="user_nameEdit" class="form-control">
                </div>
                <br>
                <div class="form-group">
                    <label for="">Email</label>
                    <input type="text" name="email" id="user_emailEdit" class="form-control">
                </div>
                <br>
                <div class="form-group">
                    <label for="">Password</label>
                    <input type="password" name="password" id="user_passwordEdit" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Plan</label>
                    <select class="form-control selectpicker" name="plan" data-style="btn btn-link" id="selectplan">
                        <option value="">----Select Plan----</option>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->period); ?>"><?php echo e($item->name); ?> &nbsp; ( $<?php echo e($item->price); ?> )</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btn-editUser" class="btn btn-primary">Edit</button>
            </div>
        </form>
      </div>
    </div>
  </div>

<script type="text/javascript">
    $(document).ready(function(){
        $(document).on('click','#btn-addUser',function(){

            var data = $("#addUser-form").serialize();
            if($('#user_name').val() == '')
            {
                return false;
            }
            else if($('#user_email').val() == '')
            {
                return false;
            }
            else if($('#user_password').val() == '')
            {
                return false;
            }
            else
            {
                $.ajax({
                    url:"/ajax/create_user",
                    type: 'post',
                    dataType: 'json',
                    data: data,

                    success: function(result){
                        if(result == '1')
                        {

                        $('#addUserModal').modal('hide');
                        swal({ title:"Successfuly created!", text: "", type: "success", buttonsStyling: false, confirmButtonClass: "btn btn-success"});
                        location.reload();
                        }
                        else if(result == 'email')
                        {
                            $('#addUserModal').modal('hide');
                        swal({ title:"Something wrong!", text: "This email already exsist.", type: "error", buttonsStyling: false, confirmButtonClass: "btn btn-success"});
                        }
                        else if(result == 'name')
                        {
                            $('#editUserModal').modal('hide');
                        swal({ title:"Something wrong!", text: "This name already exsist.", type: "error", buttonsStyling: false, confirmButtonClass: "btn btn-success"});
                        }
                    }
                });
            }
        });
        $(document).on('click','#btn_addUser',function(){
            $('#user_name').val('');
            $('#user_email').val('');
            $('#user_password').val('');
        });
        $(document).on('click','.btn-editUser',function(){
            $('#user_idEdit').val($(this).data('id'));
            $('#user_nameEdit').val($(this).data('name'));
            $('#user_emailEdit').val($(this).data('email'));
            var period = $(this).data('period');

            $("#selectplan").val(period).prop('selected', true);
            $('#user_passwordEdit').val($(this).data('password'));
        });

        $(document).on('click','#btn-editUser',function(){

            var data = $("#editUser-form").serialize();
            if($('#user_nameEdit').val() == '')
            {
                return false;
            }
            else if($('#user_emailEdit').val() == '')
            {
                return false;
            }
            else
            {
                $.ajax({
                    url:"/ajax/edit_user",
                    type: 'post',
                    dataType: 'json',
                    data: data,

                    success: function(result){
                        if(result == '1')
                        {

                        $('#editUserModal').modal('hide');
                        swal({ title:"Successfuly sent!", text: "", type: "success", buttonsStyling: false, confirmButtonClass: "btn btn-success"});
                        location.reload();
                        }
                        else if(result == 'email')
                        {
                            $('#editUserModal').modal('hide');
                        swal({ title:"Something wrong!", text: "This email already exsist.", type: "error", buttonsStyling: false, confirmButtonClass: "btn btn-success"});
                        }
                        else if(result == 'name')
                        {
                            $('#editUserModal').modal('hide');
                        swal({ title:"Something wrong!", text: "This name already exsist.", type: "error", buttonsStyling: false, confirmButtonClass: "btn btn-success"});
                        }
                    }
                });
            }
            });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\9\project_manager\project\project_manager\resources\views/user/user.blade.php ENDPATH**/ ?>