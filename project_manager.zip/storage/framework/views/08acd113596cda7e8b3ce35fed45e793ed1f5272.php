<?php $__env->startSection('content'); ?>
    <div class="banner py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6 vertical-middle">
                    <div>
                        <h1 class="home_title">More than just messaging</h1>
                        <p>Run your business with Flock</p>


                    </div>
                </div>
                <div class="col-md-6 vertical-middle">
                    <div class="bannar_image">
                        <img src="<?php echo e(asset('/img/home.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\9\project_manager\project\project_manager\resources\views/welcome.blade.php ENDPATH**/ ?>