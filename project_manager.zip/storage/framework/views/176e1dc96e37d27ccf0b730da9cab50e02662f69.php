<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-6">
           <p class="dash_title">Inbox</p>
        </div>
        <?php if(count($contacts)>0): ?>
            <div class="col-md-6 text-right">
                <input type="checkbox" name="" id="select_all">
                <button type="button" class="btn_trans btn_col_red btn_message_all" disabled>Delete All</button>
            </div>
        <?php endif; ?>
        <div class="col-md-12">
            <form action="" id="inbox_form" method="post">
                <?php echo csrf_field(); ?>
                <table class="table">
                    <tbody>
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="chk_message_item" name="message_id[]" value="<?php echo e($item->id); ?>">
                                </td>
                                <td>
                                    <a href="<?php echo e(url('/dashboard/inbox',$item->id)); ?>"><?php echo e($item->name); ?></a>
                                </td>
                                <td>
                                    <button type="button" class="btn_trans btn_col_red btn_message_item" data-id="<?php echo e($item->id); ?>"><i class="fas fa-trash-alt"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </form>
        </div>


    </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        $(document).on('click','.btn_message_item',function(){
            var id = $(this).data('id');
            $.ajax({
                url:"/ajax/delete_message",
                type: 'get',
                dataType: 'json',
                data: {id:id},

                success: function(result){
                   if(result)
                   {
                       location.reload();
                   }
                }
            });
        });
        $(document).on('click','.btn_message_all',function(){
            var id = 0;
            $.ajax({
                url:"/ajax/delete_message",
                type: 'get',
                dataType: 'json',
                data: {id:id},

                success: function(result){
                   if(result)
                   {
                       location.reload();
                   }
                }
            });
        });
        $("#select_all").change(function() {
            if(this.checked) {
                $(".btn_message_all").prop('disabled', false);
                $(".chk_message_item").each(function () {
                    $(this).prop('checked',true);
                });
            }
            else
            {
                $(".btn_message_all").prop('disabled', true);
                $(".chk_message_item").each(function () {
                    $(this).prop('checked',false);
                });

            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\9\project_manager\project\project_manager\resources\views/user/inbox.blade.php ENDPATH**/ ?>