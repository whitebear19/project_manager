<?php $__env->startSection('style'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.easypiechart.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <?php if(Auth::user()->role > 0): ?>
        <div class="col-md-4">

        </div>
        <div class="col-md-4">
            <label for="">Sort By:</label> &nbsp;&nbsp;
            <select name="" class="form-control" id="" style="width:100px;display:inline-block;">
                <option value="">Oldest</option>
                <option value="">Latest</option>
            </select>
        </div>
        <?php if(Auth::user()->role == '1'): ?>
            <div class="col-md-4">
                <a href="<?php echo e(route('newproject')); ?>" class="btn btn-primary">Create New Project</a>
            </div>
        <?php endif; ?>

        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-12">
            <ul class="project_list">
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url('/dashboard/project',$item['id'])); ?>">
                            <div class="project_item">
                                <div>
                                <i class="fas fa-folder" style="color:<?php echo e($item['color']); ?>"></i>
                                    <span class="project_title">
                                        <?php echo e($item['title']); ?>

                                    </span>
                                </div>
                                <div class="project_progress">
                                    <span class="chart" data-percent="<?php echo e($item['pro']); ?>">
                                        <span class="percent <?php if($item['pro'] == '100'): ?>
                                            adjust
                                        <?php endif; ?>"></span>
                                    </span>
                                </div>
                            </div>
                        </a>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(function() {
		$('.chart').easyPieChart({
			easing: 'easeOutBounce',
			onStep: function(from, to, percent) {
				$(this.el).find('.percent').text(Math.round(percent));
			}
		});
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\9\project_manager\project\project_manager\resources\views/user/dashboard.blade.php ENDPATH**/ ?>